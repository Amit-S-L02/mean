let usersDisplay = document.getElementById("nou");
let activeOption = document.getElementById("active-option");
let isLoggedIn = false;

let users = [{
    username: "Prajwal",
    password:"123456",
    email:"hey@prajwalpatil.com",
    score: 30
},{
    username: "Anirudh",
    password:"123456",
    email:"ani@gmail.com",
    score:2

},{
    username: "Sidd",
    password:"123456",
    email:"sid@gmail.com",
    score:5

},{
    username: "Ram",
    password:"123456",
    email:"ram@gmail.com",
    score:20
}]

usersDisplay.textContent = users.length;

const sortUsers = function(){
    let tempUser;
    for(let i=0;i<users.length-1;i++){
        for(let j=0;j<users.length-i-1;j++){
            if(users[j].score < users[j+1].score){
                tempUser = users[j+1];
                users[j+1] = users[j];
                users[j] = tempUser;
            }
        }
    }
}

//Login
if(activeOption.textContent == "Login"){
    console.log("Login Page!");
    let loginButton = document.getElementById("login-btn");
    let loginPassword = document.getElementById("login-password");
    let messageDisplay = document.getElementById("message");
    let loginId = document.getElementById("login-id");
    let userTemp ={
        username: "",
        password: ""
    }
    loginButton.addEventListener("click",(e) =>{
        isLoggedIn = false;
        e.preventDefault();
        userTemp.username = loginId.value;
        userTemp.password = loginPassword.value;
        loginId.value = "";
        loginPassword.value = "";
        for(let i=0;i<users.length;i++){
            if(users[i].username == userTemp.username && users[i].password == userTemp.password){
                console.log("AUTHENTICATION SUCCESSFUL!");
                messageDisplay.textContent = "You've successfully Logged In!";
                isLoggedIn = true;
                break;
            }
        }
        if(!isLoggedIn){
            console.log("AUTHENTICATION FAILED!");
            messageDisplay.textContent = "Invalid Username/Password";
        }
    })
}
else if(activeOption.textContent == "Register"){ 
    let registerButton = document.getElementById("register-btn");
    let registerPassword = document.getElementById("register-password");
    let registerRePassword = document.getElementById("register-repassword");
    let registerUsername = document.getElementById("register-username");
    let registerEmail = document.getElementById("register-email");
    let messageDisplay = document.getElementById("message");
    let userTemp ={
        username: "",
        password: "",
        email: "",
        score:0
    }
    registerButton.addEventListener("click",(e)=> {
        e.preventDefault();
        isLoggedIn = false;
        if(registerUsername.value == "" || registerPassword.value == "" || registerEmail.value == ""){
            messageDisplay.textContent = "Missing fields";
            return
        }
        else if(registerPassword.value == registerRePassword.value){
            userTemp.username = registerUsername.value;
            userTemp.password = registerPassword.value;
            userTemp.email = registerEmail.value;
            for(let i=0;i<users.length;i++){
                if(userTemp.email == users[i].email){
                    messageDisplay.textContent = "Email already exists!";
                    registerEmail.value = "";
                    return;
                }
                if(userTemp.username == users[i].username){
                    messageDisplay.textContent = "Username already exists!";
                    registerUsername.value = "";
                    return;
                }
            }
            users.push(userTemp);
            console.log("Registration successful!");
            messageDisplay.textContent = "Registration successful!";
            console.log(users[users.length-1]);
            registerUsername.value = "";
            registerEmail.value = "";
            registerPassword.value = "";
            registerRePassword.value = "";
            usersDisplay.textContent = users.length;
        }
        else{
            console.log("Retype your password");
            messageDisplay.textContent = "Retype your password";
            registerPassword.value = "";
            registerRePassword.value = "";
        }
    })
}
else if(activeOption.textContent == "Results"){
    sortUsers();
    let uName = document.querySelector(".results-username");
    let uEmail = document.querySelector(".results-email");
    let uScore = document.querySelector(".results-score");
    uName.textContent = users[0].username
    uEmail.textContent = users[0].email
    uScore.textContent = "Score: "+ users[0].score

}
